<script>
        $(document).ready(function(){
            $( "#from" ).datepicker({
                dateFormat: 'yy-mm-dd',
                defaultDate: null,
                changeMonth: true,
                minDate: 0,
                //maxDate:0,
                numberOfMonths: 1,
                
            });
            //jquery date picker configuration
            
        });
</script>
<?php
    $row = $get_data[0]; 
?>
<div class="row">
	<div class="col-md-12">
		<div class="tab-item">
			<div class="tab-pane active" id="tab_0">
				<div class="portlet box blue">
					<div class="portlet-title">
						<div class="caption">
							<i class="fa fa-reorder"></i><?php echo $title;?>
						</div>
						
					</div>
					<div class="portlet-body form">
						<!-- BEGIN FORM-->
						<form action="" method="post" class="form-horizontal" enctype='multipart/form-data'>
							<div class="form-body">
							<h3>Detail</h3>
								<div class="form-group">
									<label class="col-md-3 control-label">Item Name</label>
									<div class="col-md-4">
										<input type="text" class="form-control" name="item_name" placeholder="Item Title" value="<?php echo $row["item_name"]; ?>" required>
									</div>
								</div>
								
								<div class="form-group">
									<label class="col-md-3 control-label">Item Normal Price</label>
									<div class="col-md-4">
										<input type="text" class="form-control"   placeholder="Item Normal Price" value="<?php echo $row["item_curent_price"]; ?>" required>
									</div>
								</div>
								
								
								<div class="form-group">
									<label class="col-md-3 control-label">Item Image</label>
									<div class="col-md-4">
                                                                                <img src="<?php echo base_url("media/item/low/".$row["item_thumb"]);?>" height="150px">
                                                                                <input type="hidden" name="photo_status" id="photo_status" value="0">
                                                                                <input type="button" value="Change Photo" class="button blue-gradient" id="photo">
                                                                                <p class="button-height inline-label pt" style="display:none">
                                                                                        <?php
                                                                                                echo form_upload("item_thumb","","id='photos'");
                                                                                        ?>
                                                                                </p>
                                                                        </div>
								</div>
							</div>

							<div class="form-body">
							
								<div class="form-group">
									<label class="col-md-3 control-label">Item Short Desc</label>
									<div class="col-md-4">
										<textarea class="form-control" name="item_short_desc" placeholder="Item Short Description" required><?php echo $row["item_short_desc"]; ?></textarea>
									</div>
								</div>
								
								<div class="form-group">
									<label class="col-md-3 control-label">Item Long Desc</label>
									<div class="col-md-4">
										<textarea class="form-control" name="item_long_desc" placeholder="Item Long Description" required><?php echo $row["item_long_desc"]; ?></textarea>
									</div>
								</div>
								
								<?php
                                                                $dt= explode(" ", $row["item_date_start"]);
                                                                $date_bid=$dt[0];
                                                                $time_bid=$dt[1];
                                                                $time_bid=explode(":",$time_bid);
                                                                $h=$time_bid[0];
                                                                $m=$time_bid[1]
                                                                 ?>
								<div class="form-group">
									<label class="col-md-3 control-label">Start Bid Date</label>
									<div class="col-md-4">
										<input type="text" class="form-control" name="bid_date" id="from" value="<?php echo $date_bid; ?>" placeholder="Date Start">
									
									</div>
								</div>
								<div class="form-group">
									<label class="col-md-3 control-label">Start Bid Time</label>
									<div class="col-md-4">
										<select name="bid_h">
											<option>Hours</option>
											<?php
                                                                                                $select="";
												for($i=0;$i<24;$i++){
                                                                                                    if($i==$h){
                                                                                                        $select="selected='selected'";
                                                                                                    }
                                                                                                    else{
                                                                                                        $select="";
                                                                                                    }
													if($i<10){
														?>
															<option <?php echo $select; ?> value="0<?php echo $i;?>">0<?php echo $i;?></option>
														<?php
													}
													else{
														?>
															<option <?php echo $select; ?> value="<?php echo $i;?>"><?php echo $i;?></option>
														<?php
													}
													
												}
											?>
										</select>	


										<select name="bid_m">
											<option>minute</option>
											<?php 
												$time=0;
                                                                                                $select="";
												for($i=0;$i<6;$i++){
                                                                                                        if($m==$time){
                                                                                                            $select="selected='selected'";
                                                                                                            }
                                                                                                        else{
                                                                                                            $select="";
                                                                                                        }
														if($time=="0"){
															?>
																<option <?php echo $select; ?> value="0<?php echo $time;?>">0<?php echo $time;?></option>
															<?php
														}
														else{
															?>
																<option <?php echo $select; ?> value="<?php echo $time;?>"><?php echo $time;?></option>
															<?php
														}
														
													
													$time=$time+10;
												}
											?>
										</select>	
									
									</div>
								</div>
							</div>

							<div class="form-body">
								<h3>Extras</h3>
								<?php
									//print_r("<pre>");
									//print_r($get_extras);
									//print_r("</pre");
								?>
								<div class="form-group">
									<?php
										$i=0;
										foreach ($get_extras as $row) {
											$checked="";
											
											if(!empty($row["menu"])){
												$row2=$row["menu"][0];
												if($row2["actived"]=="1"){
													$checked="checked='checked'";
												}
												else{
													$checked="";
												}
												?>
													
													<div class="col-md-4">
														<input type="checkbox" <?php echo $checked; ?> name="extras<?php echo $i; ?>" value="<?php echo $row["extras_id"]; ?>"><?php echo $row["extras_name"]; ?>
														<input type="hidden" name="item_extras_id<?php echo $i;?>" value="<?php echo $row2["item_extras_id"] ?>">
														<input type="hidden" name="extras_id<?php echo $i;?>" value="<?php echo $row["extras_id"]; ?>">
													</div>
												<?php
											}
											else{
												?>
													
													<div class="col-md-4">
														<input type="checkbox" name="extras<?php echo $i; ?>" value="<?php echo $row["extras_id"]; ?>"><?php echo $row["extras_name"]; ?>
														<input type="hidden" name="item_extras_id<?php echo $i;?>" value="">
														<input type="hidden" name="extras_id<?php echo $i;?>" value="<?php echo $row["extras_id"]; ?>">
														
													</div>
												<?php
											}

										$i++;	
										}
									?>
									<input type="hidden" name="extras" value="<?php echo $i;?>">
								</div>
								
							</div>
							<div class="form-actions fluid">
								<div class="col-md-offset-3 col-md-9">
									<button type="submit" class="btn blue">Submit</button>
									<button type="button" class="btn default">Cancel</button>
								</div>
							</div>
						</form>
						<!-- END FORM-->
					</div>
					
					<div class="portlet-body form">
						<!-- BEGIN FORM-->
						<form action="" method="post" class="form-horizontal" enctype='multipart/form-data'>
							<div class="form-body">
							<h3>Image</h3>
								<?php
									foreach($get_image as $row3){
										?>
										
										<div class="form-group">
											<label class="col-md-3 control-label">Item Image</label>
											<div class="col-md-4">
												<img src="<?php echo base_url("media/item/low/".$row3["item_image"]);?>" height="150px">
												<input type="hidden" name="photo_status" id="photo_status" value="0">
												<input type="button" value="Change Photo" class="button blue-gradient" id="photo">
												<p class="button-height inline-label pt" style="display:none">
													<?php
														echo form_upload("item_thumb","","id='photos'");
													?>
												</p>
											</div>
										</div>
										<?php
										
									}
								?>
										
							</div>
							<div class="form-actions fluid">
								<div class="col-md-offset-3 col-md-9">
									<button type="submit" class="btn blue">Submit</button>
									<button type="button" class="btn default">Cancel</button>
								</div>
							</div>
						</form>
						<!-- END FORM-->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>				

<script>
	$(document).ready(function(){
		$("#photo").click(function(){
                        //alert("aaa");
			var vala=$(this).attr("value");
			if(vala=="Change Photo"){
				$(".pt").fadeIn();
				$(this).val("Unchange Photo");
				$("#photos").attr("required",true);
				$("#photo_status").val("1");
			}else{
				$(".pt").hide();
				$(this).val("Change Photo");
				$("#photos").attr("required",false);
				$("#photo_status").val("0");
			}
		});
	});
</script>
<script>
    
$(document).ready(function(){
        
		<?php
		    for ($i=1; $i<=5; $i++){
		?>
		    xx<?php echo $i;?>=3;
		    $('#photos-<?php echo $i; ?>').val(xx<?php echo $i;?>);
		    $('#addRow2-<?php echo $i;?>').click(function(){
			    $(".mnc2-<?php echo $i;?>").fadeIn();
			    $(this).attr('disabled','disabled');
			    row = $(this).attr('row');
			    $("select#event_city_id"+row).attr("required",true);
                            $("input#event_city_lat"+row).attr("required",true);
                            $("input#event_city_lang"+row).attr("required",true);
                            
			    $('#row<?php echo $i;?>-'+row).fadeIn(function(){
				    row++;
				    xx<?php echo $i;?>=xx<?php echo $i;?>+1;
				    
				    
				    $('#addRow2-<?php echo $i;?>').attr('row',row);
				    $('#addRow2-<?php echo $i;?>').removeAttr('disabled');
				    $('#photos-<?php echo $i; ?>').val(xx<?php echo $i;?>);
				   
				    //$('#admins1').val(x4);
			    });		
				    
		    });
		    $('#cancel2-<?php echo $i; ?>').click(function(){
					row=$("#addRow2-<?php echo $i;?>").attr('row');
					//alert (row);
					row=row-1;
					xx<?php echo $i;?>=xx<?php echo $i;?>-1;
					
					$("select#event_city_id"+row).attr("required",false);
                                        $("input#event_city_lat"+row).attr("required",false);
                                        $("input#event_city_lang"+row).attr("required",false);
					$("input#photos-<?php echo $i; ?>").val(xx<?php echo $i;?>);
					//$("input#admins1").val(x4);
					$('#row<?php echo $i;?>-'+row).hide();
					if(row==4)
					{
						$(".mnc2-<?php echo $i; ?>").hide();
					}
                                        $('#addRow2-<?php echo $i;?>').removeAttr('disabled');
					$("#addRow2-<?php echo $i;?>").attr('row',row);
					
			});
		    
		
		<?php
		    }
		?>
		
    });
</script>