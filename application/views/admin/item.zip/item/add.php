<script>
        $(document).ready(function(){
            $( "#from" ).datepicker({
                dateFormat: 'yy-mm-dd',
                defaultDate: null,
                changeMonth: true,
                minDate: 0,
                //maxDate:0,
                numberOfMonths: 1,
                
            });
            //jquery date picker configuration
            
        });
</script>

<div class="row">
	<div class="col-md-12">
		<div class="tab-item">
			<div class="tab-pane active" id="tab_0">
				<div class="portlet box blue">
					<div class="portlet-title">
						<div class="caption">
							<i class="fa fa-reorder"></i><?php echo $title;?>
						</div>
						
					</div>
					<div class="portlet-body form">
						<!-- BEGIN FORM-->
						<form action="<?php echo site_url("admin_item/add");?>" method="post" class="form-horizontal" enctype='multipart/form-data'>
							<div class="form-body">
							<h3>Detail</h3>
								<div class="form-group">
									<label class="col-md-3 control-label">Item Name</label>
									<div class="col-md-4">
										<input type="text" class="form-control" name="item_name" placeholder="Item Title" required>
									</div>
								</div>
								
								<div class="form-group">
									<label class="col-md-3 control-label">Item Normal Price</label>
									<div class="col-md-4">
										<input type="text" class="form-control"  name="item_curent_price" placeholder="Item Normal Price" required>
									</div>
								</div>
								
								
								<div class="form-group">
									<label class="col-md-3 control-label">Item Thumb Image</label>
									<div class="col-md-4">
										<input type="file" class="form-control" name="item_thumb" placeholder="Item Image">
									</div>
								</div>
							</div>

							<div class="form-body">
							
								<div class="form-group">
									<label class="col-md-3 control-label">Item Short Desc</label>
									<div class="col-md-4">
										<textarea class="form-control" name="item_short_desc" placeholder="Item Short Description" required></textarea>
									</div>
								</div>
								
								<div class="form-group">
									<label class="col-md-3 control-label">Item Long Desc</label>
									<div class="col-md-4">
										<textarea class="form-control" name="item_long_desc" placeholder="Item Long Description" required></textarea>
									</div>
								</div>
								
								
								<div class="form-group">
									<label class="col-md-3 control-label">Start Bid Date</label>
									<div class="col-md-4">
										<input type="text" class="form-control" name="bid_date" id="from" value="" placeholder="Date Start">
									
									</div>
								</div>
								<div class="form-group">
									<label class="col-md-3 control-label">Start Bid Time</label>
									<div class="col-md-4">
										<select name="bid_h">
											<option>Hours</option>
											<?php 
												for($i=0;$i<24;$i++){
													if($i<10){
														?>
															<option value="0<?php echo $i;?>">0<?php echo $i;?></option>
														<?php
													}
													else{
														?>
															<option value="<?php echo $i;?>"><?php echo $i;?></option>
														<?php
													}
													
												}
											?>
										</select>	


										<select name="bid_m">
											<option>minute</option>
											<?php 
												$time=0;
												for($i=0;$i<6;$i++){
														if($time=="0"){
															?>
																<option value="0<?php echo $time;?>">0<?php echo $time;?></option>
															<?php
														}
														else{
															?>
																<option value="<?php echo $time;?>"><?php echo $time;?></option>
															<?php
														}
														
													
													$time=$time+10;
												}
											?>
										</select>	
									
									</div>
								</div>
							</div>
							<div class="form-body">
								<h3>Image</h3>
								<div class="form-group">
									<label class="col-md-3 control-label">Image 1</label>
									<div class="col-md-4">
										<input type="file" class="form-control" name="item_image1" placeholder="Item Image">
									</div>
								</div>
								
								<div class="form-group">
									<label class="col-md-3 control-label">Image 2</label>
									<div class="col-md-4">
										<input type="file" class="form-control" name="item_image2" placeholder="Item Image">
									</div>
								</div>
								
								
								<div class="form-group">
									<label class="col-md-3 control-label">Image 3</label>
									<div class="col-md-4">
										<input type="file" class="form-control" name="item_image3" placeholder="Item Image">
									</div>
								</div>
								<?php
                                                for($i=4;$i<=10;$i++){
                                                    ?>
                                                    <div class="form-group" id='row1-<?php echo $i; ?>' style="display: none;">
														<label class="col-md-3 control-label">Image <?php echo $i ?></label>
														<div class="col-md-4">
															<input type="file" class="form-control" name="item_image<?php echo $i ?>" placeholder="Item Image">
														</div>
													</div>
                                                    
                                                    
                                                    
                                                <?php
                                                }
                                            ?>
                                                                        
                                            
                                            <p class="button-height inline-label">
                                              <input type="hidden" name="images" id="photos-1"><br>
                                              <button type="button" id="addRow2-1" class="btn" row="4">Add More Image</button>
                                              <button type="button"  class="button blue-gradient mnc2-1 " id="cancel2-1" style=" display: none;">Cancel</button>
                                              
                                            </p>
                                                                        
									
							</div>
							<div class="form-body">
								<h3>Extras</h3>
								<div class="form-group">
									<?php
										foreach ($extras as $key => $value) {
											if($key!=""){

											?>
												<div class="col-md-4">
													<input type="checkbox" name="extras[]" value="<?php echo $key; ?>"><?php echo $value; ?>
												</div>
											<?php

											}
										}
									?>

												
									
									
								</div>
								
							</div>
							<div class="form-actions fluid">
								<div class="col-md-offset-3 col-md-9">
									<button type="submit" class="btn blue">Submit</button>
									<button type="button" class="btn default">Cancel</button>
								</div>
							</div>
						</form>
						<!-- END FORM-->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>				

<script>
$(document).ready(function(){
        
		<?php
		    for ($i=1; $i<=5; $i++){
		?>
		    xx<?php echo $i;?>=3;
		    $('#photos-<?php echo $i; ?>').val(xx<?php echo $i;?>);
		    $('#addRow2-<?php echo $i;?>').click(function(){
			    $(".mnc2-<?php echo $i;?>").fadeIn();
			    $(this).attr('disabled','disabled');
			    row = $(this).attr('row');
			    $("select#event_city_id"+row).attr("required",true);
                            $("input#event_city_lat"+row).attr("required",true);
                            $("input#event_city_lang"+row).attr("required",true);
                            
			    $('#row<?php echo $i;?>-'+row).fadeIn(function(){
				    row++;
				    xx<?php echo $i;?>=xx<?php echo $i;?>+1;
				    
				    
				    $('#addRow2-<?php echo $i;?>').attr('row',row);
				    $('#addRow2-<?php echo $i;?>').removeAttr('disabled');
				    $('#photos-<?php echo $i; ?>').val(xx<?php echo $i;?>);
				   
				    //$('#admins1').val(x4);
			    });		
				    
		    });
		    $('#cancel2-<?php echo $i; ?>').click(function(){
					row=$("#addRow2-<?php echo $i;?>").attr('row');
					//alert (row);
					row=row-1;
					xx<?php echo $i;?>=xx<?php echo $i;?>-1;
					
					$("select#event_city_id"+row).attr("required",false);
                                        $("input#event_city_lat"+row).attr("required",false);
                                        $("input#event_city_lang"+row).attr("required",false);
					$("input#photos-<?php echo $i; ?>").val(xx<?php echo $i;?>);
					//$("input#admins1").val(x4);
					$('#row<?php echo $i;?>-'+row).hide();
					if(row==4)
					{
						$(".mnc2-<?php echo $i; ?>").hide();
					}
                                        $('#addRow2-<?php echo $i;?>').removeAttr('disabled');
					$("#addRow2-<?php echo $i;?>").attr('row',row);
					
			});
		    
		
		<?php
		    }
		?>
		
    });
</script>